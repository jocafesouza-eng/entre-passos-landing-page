import React from 'react';
import { Check, ShieldCheck, Download } from 'lucide-react';

const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-24 bg-brand-dark text-white relative">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row">
          
          {/* Left Side: Summary */}
          <div className="md:w-5/12 bg-slate-100 p-8 text-brand-dark flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-bold mb-4">Você recebe hoje:</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                    <span className="text-sm font-medium">eBook Completo (PDF)</span>
                </li>
                <li className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                    <span className="text-sm font-medium">Audiobook Premium</span>
                </li>
                <li className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                    <span className="text-sm font-medium">Guia de Preparação</span>
                </li>
                <li className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                    <span className="text-sm font-medium">Acesso Vitalício</span>
                </li>
              </ul>
            </div>
            
            <div className="mt-8 pt-6 border-t border-slate-300">
               <div className="flex items-center gap-4">
                  <ShieldCheck className="w-12 h-12 text-brand-dark" />
                  <div>
                      <p className="font-bold text-sm">Garantia de 7 Dias</p>
                      <p className="text-xs text-slate-500">Seu dinheiro de volta sem perguntas.</p>
                  </div>
               </div>
            </div>
          </div>

          {/* Right Side: Price */}
          <div className="md:w-7/12 bg-brand-primary p-10 flex flex-col items-center justify-center text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-brand-accent text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                OFERTA LIMITADA
            </div>
            
            <p className="text-slate-300 text-sm uppercase tracking-wide mb-2">Por apenas</p>
            <div className="flex items-center gap-3 justify-center mb-6">
                <span className="text-slate-400 line-through text-xl">R$ 29,90</span>
                <span className="text-5xl font-bold text-white">R$ 19,90</span>
            </div>
            
            <button className="w-full bg-brand-accent hover:bg-amber-500 text-white font-bold py-4 rounded-xl shadow-lg transform transition hover:scale-105 active:scale-95 mb-4 flex items-center justify-center gap-2">
                <Download className="w-5 h-5" />
                QUERO COMEÇAR MINHA JORNADA
            </button>
            
            <p className="text-xs text-slate-400">
                Pagamento 100% seguro. Acesso enviado por e-mail imediatamente.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Pricing;