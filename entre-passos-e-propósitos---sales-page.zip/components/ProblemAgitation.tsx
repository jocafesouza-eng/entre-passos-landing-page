import React from 'react';
import { HelpCircle, AlertCircle, Heart } from 'lucide-react';

const ProblemAgitation: React.FC = () => {
  return (
    <section className="py-20 bg-slate-50 container mx-auto px-4">
      <div className="max-w-4xl mx-auto text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-bold text-brand-dark mb-6 font-serif">
          Você sente o chamado, mas não sabe por onde começar?
        </h2>
        <p className="text-lg text-slate-600 leading-relaxed">
          O Caminho da Fé é mais do que uma trilha física. É um desafio que exige preparo. 
          Muitos peregrinos desistem ou sofrem desnecessariamente porque focam apenas na mochila, 
          esquecendo o mais importante: <strong>o interior.</strong>
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {[
          {
            icon: <HelpCircle className="w-10 h-10 text-brand-primary" />,
            title: "Incerteza",
            text: "Você tem dúvidas sobre o preparo físico, o que levar e como lidar com os desafios da estrada?"
          },
          {
            icon: <AlertCircle className="w-10 h-10 text-brand-accent" />,
            title: "Medo do Desconhecido",
            text: "Receio de não aguentar o ritmo ou de se perder em meio aos próprios pensamentos durante a solidão do trajeto?"
          },
          {
            icon: <Heart className="w-10 h-10 text-red-500" />,
            title: "Falta de Propósito",
            text: "Sente que precisa de mais clareza espiritual antes de dar o primeiro passo rumo ao santuário?"
          }
        ].map((item, idx) => (
          <div key={idx} className="bg-white p-8 rounded-2xl shadow-lg border-b-4 border-brand-primary hover:-translate-y-2 transition-transform duration-300">
            <div className="mb-4 bg-slate-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
              {item.icon}
            </div>
            <h3 className="text-xl font-bold text-brand-dark mb-3 text-center">{item.title}</h3>
            <p className="text-slate-600 text-center">{item.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ProblemAgitation;