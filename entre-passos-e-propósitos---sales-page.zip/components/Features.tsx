import React from 'react';
import { BookOpen, Headphones, Compass, Map, Sun, Footprints } from 'lucide-react';

const Features: React.FC = () => {
  const contentList = [
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: "Reflexões Profundas",
      description: "Textos cuidadosamente escritos para fortalecer seu propósito espiritual a cada quilômetro."
    },
    {
      icon: <Footprints className="w-6 h-6" />,
      title: "Histórias Reais",
      description: "Vivências de quem já percorreu o Caminho, com erros e acertos para você aprender."
    },
    {
      icon: <Compass className="w-6 h-6" />,
      title: "Preparo Físico e Mental",
      description: "Orientações práticas de como preparar seu corpo e sua mente para a longa jornada."
    },
    {
      icon: <Map className="w-6 h-6" />,
      title: "Dicas de Equipamento",
      description: "O que levar na mochila? Saiba o essencial para não carregar peso desnecessário."
    },
    {
      icon: <Headphones className="w-6 h-6" />,
      title: "Versão em Áudio",
      description: "Ouça o livro durante seus treinos ou durante a própria caminhada. Narrado com emoção."
    },
    {
      icon: <Sun className="w-6 h-6" />,
      title: "Pousadas e Apoio",
      description: "Dicas de lugares para descansar e acesso a descontos exclusivos para leitores."
    }
  ];

  return (
    <section className="py-20 bg-brand-dark text-white relative overflow-hidden">
        {/* Abstract shapes */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary rounded-full blur-3xl opacity-30 -mr-32 -mt-32"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-brand-accent rounded-full blur-3xl opacity-20 -ml-48 -mb-48"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold mb-4">
            O Que Você Vai Encontrar?
          </h2>
          <p className="text-slate-300 max-w-2xl mx-auto">
            Um guia completo que une a praticidade do planejamento com a profundidade da experiência espiritual.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {contentList.map((feature, idx) => (
            <div key={idx} className="bg-white/5 backdrop-blur-sm p-6 rounded-xl border border-white/10 hover:bg-white/10 transition-colors">
              <div className="text-brand-gold mb-4 p-3 bg-brand-gold/10 rounded-lg inline-block">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-2 text-white">{feature.title}</h3>
              <p className="text-slate-300 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;