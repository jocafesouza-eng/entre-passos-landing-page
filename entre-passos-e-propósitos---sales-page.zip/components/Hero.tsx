import React from 'react';
import { ArrowRight, Star, MoveRight } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollToPricing = () => {
    document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header className="relative w-full min-h-[90vh] flex items-center justify-center bg-brand-dark text-white overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1518182170546-0766ce6fec56?q=80&w=2560&auto=format&fit=crop" 
          alt="Caminho da Fé Natureza" 
          className="w-full h-full object-cover opacity-30 mix-blend-overlay"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-brand-dark/90 via-brand-dark/70 to-brand-dark"></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-12 flex flex-col md:flex-row items-center gap-12">
        
        {/* Text Content */}
        <div className="flex-1 text-center md:text-left space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-accent/20 border border-brand-accent/50 text-brand-gold text-sm font-semibold uppercase tracking-wider mb-2">
            <Star className="w-4 h-4 fill-brand-gold" />
            O Guia Definitivo
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold leading-tight">
            Caminho da Fé: <br/>
            <span className="text-brand-gold">Entre Passos e Propósitos</span>
          </h1>
          
          <p className="text-lg md:text-xl text-slate-300 max-w-2xl leading-relaxed">
            Prepare seu corpo, mente e alma para a maior peregrinação da sua vida. 
            Não é apenas sobre caminhar, é sobre encontrar a si mesmo.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start pt-4">
            <button 
              onClick={scrollToPricing}
              className="group bg-brand-accent hover:bg-amber-600 text-white text-lg font-bold py-4 px-8 rounded-full shadow-[0_0_20px_rgba(245,158,11,0.5)] transition-all duration-300 transform hover:-translate-y-1 flex items-center justify-center gap-2"
            >
              Quero Começar Minha Jornada
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
          
          <p className="text-xs text-slate-400 mt-4">
            *Acesso imediato ao eBook e Audiobook
          </p>
        </div>

        {/* Book Cover Mockup */}
        <div className="flex-1 flex justify-center items-center perspective-1000">
          {/* Book Spine/3D Effect container */}
          <div className="relative w-64 md:w-80 aspect-[2/3] rounded-r-2xl shadow-2xl transform rotate-y-12 transition-transform duration-500 hover:rotate-y-0 border-l-[6px] border-white/10 bg-white">
             
             {/* Cover Image Background (Dirt Road) */}
             <div className="absolute inset-0 rounded-r-2xl overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1542259681-d4cd7187c710?q=80&w=1000&auto=format&fit=crop" 
                  alt="Estrada de Terra - Caminho da Fé" 
                  className="w-full h-full object-cover"
                />
             </div>

             {/* Overlay Card (Beige Sticker) */}
             <div className="absolute inset-0 flex items-center justify-center p-4">
                <div className="bg-[#fefce8] w-full rounded-[2rem] p-6 shadow-xl flex flex-col items-center justify-center text-center opacity-95">
                  <h2 className="text-3xl font-serif text-slate-900 leading-none mb-1 tracking-wide">
                    CAMINHO <br/> DA FÉ
                  </h2>
                  <p className="text-sm font-serif text-slate-800 my-1 tracking-widest uppercase">
                    Entre Passos e
                  </p>
                  <h3 className="text-2xl font-serif text-slate-900 tracking-wide mb-4">
                    PROPÓSITOS
                  </h3>
                  
                  {/* Arrow Icon */}
                  <MoveRight className="w-8 h-8 text-[#d97706] stroke-[3]" />
                </div>
             </div>

             {/* Lighting/Sheen Overlay for Realism */}
             <div className="absolute inset-0 bg-gradient-to-r from-black/20 to-transparent pointer-events-none rounded-r-2xl"></div>
             <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-black/10 pointer-events-none rounded-r-2xl"></div>
          </div>
        </div>

      </div>

      <div className="absolute bottom-0 w-full h-24 bg-gradient-to-t from-slate-50 to-transparent"></div>
    </header>
  );
};

export default Hero;