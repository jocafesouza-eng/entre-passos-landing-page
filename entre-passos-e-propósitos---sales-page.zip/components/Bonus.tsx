import React from 'react';
import { Calculator, CheckCircle2 } from 'lucide-react';

const Bonus: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-slate-100 to-white">
      <div className="container mx-auto px-4">
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-200">
          <div className="flex flex-col md:flex-row">
            <div className="md:w-1/2 p-10 flex flex-col justify-center">
              <span className="text-brand-accent font-bold tracking-wider text-sm uppercase mb-2">Bônus Exclusivo</span>
              <h2 className="text-3xl font-serif font-bold text-brand-dark mb-4">
                CRM de Planejamento da Jornada
              </h2>
              <p className="text-slate-600 mb-6">
                Para quem quer ir além: uma ferramenta prática e automática para calcular todos os seus gastos.
              </p>
              <ul className="space-y-3 mb-8">
                {[
                  "Calculadora automática de gastos",
                  "Planejamento de hospedagem",
                  "Controle de alimentação",
                  "Organização financeira completa"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-brand-primary font-medium">
                    <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <div className="inline-block bg-green-100 text-green-800 px-4 py-2 rounded-lg text-sm font-semibold self-start">
                Disponível como opcional no checkout
              </div>
            </div>
            
            <div className="md:w-1/2 bg-brand-primary flex items-center justify-center p-10 relative overflow-hidden">
               <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
               <div className="text-center relative z-10">
                 <Calculator className="w-32 h-32 text-white/90 mx-auto mb-6" />
                 <p className="text-white text-lg font-medium opacity-90">Ferramenta Exclusiva</p>
                 <p className="text-3xl font-bold text-brand-gold mt-2">100% Prática</p>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Bonus;