import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-500 py-8 text-center text-sm">
      <div className="container mx-auto px-4">
        <p className="mb-2">&copy; {new Date().getFullYear()} Entre Passos e Propósitos. Todos os direitos reservados.</p>
        <div className="flex justify-center gap-4 mt-4">
            <a href="#" className="hover:text-slate-300">Termos de Uso</a>
            <a href="#" className="hover:text-slate-300">Política de Privacidade</a>
            <a href="#" className="hover:text-slate-300">Contato</a>
        </div>
        <p className="mt-8 text-xs max-w-2xl mx-auto opacity-50">
            Este produto não garante a obtenção de resultados. Qualquer referência ao desempenho de uma estratégia não deve ser interpretada como uma garantia de resultados.
        </p>
      </div>
    </footer>
  );
};

export default Footer;