import React from 'react';
import { Quote } from 'lucide-react';

const Author: React.FC = () => {
  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12 max-w-6xl mx-auto">
          
          <div className="lg:w-1/3">
            <div className="relative">
              <div className="absolute inset-0 bg-brand-accent rounded-full translate-x-4 translate-y-4"></div>
              <img 
                src="https://picsum.photos/id/1005/400/400" 
                alt="Jocafe Souza" 
                className="relative z-10 rounded-full w-full shadow-lg border-4 border-white grayscale hover:grayscale-0 transition-all duration-500"
              />
            </div>
          </div>

          <div className="lg:w-2/3">
            <h2 className="text-sm font-bold tracking-widest text-brand-primary uppercase mb-2">Sobre o Autor</h2>
            <h3 className="text-4xl font-serif font-bold text-brand-dark mb-6">Jocafe Souza</h3>
            
            <div className="relative pl-8 border-l-4 border-brand-gold mb-6">
                <Quote className="absolute -left-3 -top-4 w-8 h-8 text-brand-gold bg-slate-50" />
                <p className="text-xl italic text-slate-700 font-serif">
                  "Encontrei no Caminho da Fé uma forma de desacelerar, silenciar a mente e reencontrar o sentido da vida."
                </p>
            </div>

            <p className="text-slate-600 mb-4 leading-relaxed">
              Peregrino, pai, marido e criador do projeto "Entre Passos e Propósitos". 
              Jocafe não escreve apenas teorias; ele escreve sobre o suor, a poeira e as lágrimas 
              de quem viveu cada passo da jornada.
            </p>
            <p className="text-slate-600 leading-relaxed">
              Seu objetivo hoje é ajudar outras pessoas a viverem essa jornada não apenas como um desafio físico, 
              mas com consciência, leveza e transformação espiritual. Sem religiosidade imposta, mas com muita fé.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Author;