import React from 'react';
import Hero from './components/Hero';
import ProblemAgitation from './components/ProblemAgitation';
import Features from './components/Features';
import Bonus from './components/Bonus';
import Author from './components/Author';
import Pricing from './components/Pricing';
import Footer from './components/Footer';
import FloatingCTA from './components/FloatingCTA';

const App: React.FC = () => {
  return (
    <div className="min-h-screen font-sans overflow-x-hidden selection:bg-brand-accent selection:text-brand-dark">
      <Hero />
      <ProblemAgitation />
      <Features />
      <Bonus />
      <Author />
      <Pricing />
      <Footer />
      <FloatingCTA />
    </div>
  );
};

export default App;